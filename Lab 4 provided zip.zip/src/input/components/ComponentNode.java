package input.components;

public interface ComponentNode
{
	void unparse(StringBuilder sb, int level);
}
