package global;


public class Constants
{
    public static final boolean DEBUG = true;
   
    public static final String INPUT_FILE_COMMENT_PREFIX = "//";

    public static final String INPUT_FILE_EXTENSION = "json"; 
}